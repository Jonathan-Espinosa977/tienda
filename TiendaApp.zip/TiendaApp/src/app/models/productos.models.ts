export interface Productos {
    
    id: number | null;
    nombre: String;
    precio: number;
    descripcion: String;
    stock: number;
}