import { Component, OnInit, ViewChild } from '@angular/core';
import { Productos } from '../../models/productos.models';
import { ProductosService } from '../../services/productos.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap'
import Swal from "sweetalert2";
import * as ExcelJS from 'exceljs';

@Component({
  selector: 'app-productos',
  standalone: false,
  templateUrl: './productos.component.html',
  styleUrl: './productos.component.css'
})
export class ProductosComponent implements OnInit {

  @ViewChild('modalContent') modalContent: any;
  producto: Productos[] = [];
  nuevoProducto: Productos = {
    id: null,
    nombre: '',
    precio: 0,
    descripcion: '',
    stock: 0,
  };
  isEdit: boolean = false;

  constructor(
    private productosService: ProductosService,
    private modalService: NgbModal
  ) { }

  ngOnInit(): void {
    this.productosService.getProductos().subscribe(data => {
      this.producto = data;
    }),
      (error: any) => {
        console.error('Error al obtener el Producto', error);
      }
  }

  openModal(producto?: Productos): void {
    if (producto) {
      this.isEdit = true;
      this.nuevoProducto = { ...producto };
    } else {
      this.isEdit = false;
      this.nuevoProducto = { id: null, nombre: '', precio: 0, descripcion: '', stock: 0 }
    }
    const modalRef = this.modalService.open(this.modalContent, { ariaLabelledBy: 'modalCrearProductosLabel' });

    modalRef.result.finally(() => {
      const focusElment = document.getElementById('openModalButton');
      if (focusElment) {
        focusElment.focus();
      }
    });
  }

  crearProductos() {
    this.productosService.postProductos(this.nuevoProducto).subscribe(data => {
      this.producto.push(data);
      Swal.fire({
        title: 'Producto Creado',
        text: "Producto Creado Exitosamente",
        icon: 'success'
      });
      this.producto.sort();
      this.modalService.dismissAll();
    }),
      (error: any) => {
        Swal.fire({
          title: 'Error!',
          text: "Hubo un Error al Crear el Producto: " + error,
          icon: 'error'
        });
      }
  }

  updateProductos() {
    this.productosService.putProductos(this.nuevoProducto).subscribe(data => {
      const index = this.producto.findIndex(a => a.id === data.id);
      if (index !== -1) {
        this.producto[index] = { ...data };
      }
      Swal.fire({
        title: 'Producto Actualizado',
        text: "Producto Actualizado Exitosamente",
        icon: 'success'
      })
      this.producto.sort();
      this.modalService.dismissAll();
    }),
      (error: any) => {
        Swal.fire({
          title: 'Error!',
          text: "Hubo un Error al Actualizar el Producto: " + error,
          icon: 'error'
        });
      }
  }

  deleteProductos(id: number) {
    Swal.fire({
      title: 'Eliminar Productos',
      text: "¿Estás seguro que deseas eliminar el Producto?",
      icon: 'question',
      showConfirmButton: true,
      showCancelButton: true
    }).then((resp) => {
      if (resp.isConfirmed) {
        this.productosService.deleteProductos(id).subscribe({
          next: (resp) => {
            this.producto = this.producto.filter(a => a.id !== id);
            Swal.fire({
              title: 'Producto Eliminado',
              text: "Producto Eliminado Exitosamente",
              icon: 'success'
            });
          },
          error: (error: any) => {
            Swal.fire({
              title: 'Error!',
              text: "Hubo un Error al Eliminar el Producto: " + error,
              icon: 'error'
            });
          }
        });
      }
    });
  }

  exportToExcelWithExcelJS(): void {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Productos');
  
    // Añadir un título (fila 1)
    worksheet.mergeCells('A1:D1');
    const titleCell = worksheet.getCell('A1');
    titleCell.value = 'Lista de Productos';
    titleCell.font = { size: 16, bold: true };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
  
    // Definir el ancho de las columnas
    worksheet.getColumn(1).width = 20;  // Nombre
    worksheet.getColumn(2).width = 20;  // Precio
    worksheet.getColumn(3).width = 20;  // Descripcion
    worksheet.getColumn(4).width = 20;  // Stock
  
    // Agregar las cabeceras manualmente en la fila 2
    worksheet.getCell('A2').value = 'Nombre';
    worksheet.getCell('B2').value = 'Precio';
    worksheet.getCell('C2').value = 'Descripcion';
    worksheet.getCell('D2').value = 'Stock';
  
    // Estilo para las cabeceras (fila 2)
    const headerRow = worksheet.getRow(2);
    headerRow.eachCell((cell) => {
      cell.font = { bold: true, color: { argb: 'FFFFFF' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '4CAF50' } };
      cell.border = {
        top: { style: 'medium', color: { argb: '000000' } },
        left: { style: 'medium', color: { argb: '000000' } },
        bottom: { style: 'medium', color: { argb: '000000' } },
        right: { style: 'medium', color: { argb: '000000' } }
      };
    });
  
    // Asegurarnos de que this.autor contiene los datos
    if (this.producto && Array.isArray(this.producto) && this.producto.length > 0) {
      // Recorrer los datos de autores y agregar las filas de datos
      this.producto.forEach((producto) => {
        const row = worksheet.addRow([producto.nombre, producto.precio, producto.descripcion, producto.stock]);
  
        // Estilizar las celdas de la fila de datos
        row.eachCell((cell) => {
          cell.alignment = { horizontal: 'center', vertical: 'middle' }; // Alinear al centro
          cell.border = {
            top: { style: 'thin', color: { argb: '000000' } },
            left: { style: 'thin', color: { argb: '000000' } },
            bottom: { style: 'thin', color: { argb: '000000' } },
            right: { style: 'thin', color: { argb: '000000' } }
          };
        });
      });
    } else {
      console.log('No hay datos de productos para agregar');
    }
  
    // Obtener el número de filas (total de filas en la hoja)
    const rowCount = worksheet.rowCount;
  
    // Añadir un borde grueso alrededor de toda la tabla (toda la parte de los datos, incluyendo cabeceras)
    worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      row.eachCell({ includeEmpty: false }, (cell, colNumber) => {
        // Borde grueso en la fila de cabeceras (fila 2)
        if (rowNumber === 2) {
          cell.border = { // Borde más grueso en la cabecera
            top: { style: 'medium', color: { argb: '000000' } },
            left: { style: 'medium', color: { argb: '000000' } },
            bottom: { style: 'medium', color: { argb: '000000' } },
            right: { style: 'medium', color: { argb: '000000' } }
          };
        } else if (rowNumber <= rowCount) {
          // Bordes finos para las filas de datos
          cell.border = {
            top: { style: 'thin', color: { argb: '000000' } },
            left: { style: 'thin', color: { argb: '000000' } },
            bottom: { style: 'thin', color: { argb: '000000' } },
            right: { style: 'thin', color: { argb: '000000' } }
          };
        }
      });
    });
  
    // Agregar filtro a las cabeceras (A2:D2)
    worksheet.autoFilter = {
      from: 'A2', // Comienza el filtro en la celda A2
      to: 'D2'   // Y termina en la celda D2
    };
  
    // Guardar el archivo
    workbook.xlsx.writeBuffer().then((buffer) => {
      const blob = new Blob([buffer], { type: 'application/octet-stream' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'Productos.xlsx';
      link.click();
    });
  }

}