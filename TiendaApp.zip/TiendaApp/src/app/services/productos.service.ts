import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Productos } from '../models/productos.models';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {

  private apiUrl = 'http://localhost:8080/productos/';

  constructor(
    private http: HttpClient
  ) { }

  getProductos(): Observable<Productos[]>{
    return this.http.get<Productos[]>(this.apiUrl);
  }

  postProductos(producto: Productos): Observable<Productos>{
    return this.http.post<Productos>(this.apiUrl, producto);
  }

  deleteProductos(id: number): Observable<Productos>{
    return this.http.delete<Productos>(`${this.apiUrl}${id}`);
  }

  putProductos (producto: Productos): Observable<Productos>{
    return this.http.put<Productos>(`${this.apiUrl}${producto.id}`, producto);
  }
}
