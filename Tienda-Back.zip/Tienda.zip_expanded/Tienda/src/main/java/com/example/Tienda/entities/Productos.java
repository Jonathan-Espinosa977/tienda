package com.example.Tienda.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity // Anotacion para representar la entidad 'Producto' en la base de datos
@Table(name = "Productos") // Especifica el nombre de la tabla en la base de datos
public class Productos {
	
	@Id // Definición de la clave primaria de la entidad
	@Column(name = "ID")
	private Long id;
	
	// Atributo que representa el nombre del producto
	@Column(name = "NOMBRE")
	private String nombre;
	
	// Atributo que representa el precio del producto
	@Column(name = "PRECIO")
	private int precio;
	
	// Atributo que describe el producto
	@Column(name = "DESCRIPCION")
	private String descripcion;
	
	// Atributo que representa la cantidad del stock de los productos
	@Column(name = "STOCK")
	private int stock;

	// Getters y Setters para cada atributo de la clase
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
}