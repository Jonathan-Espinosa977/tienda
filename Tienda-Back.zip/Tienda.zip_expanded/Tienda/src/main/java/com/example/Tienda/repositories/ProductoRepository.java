package com.example.Tienda.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Tienda.entities.Productos;

//Interfaz que actúa como repositorio para la entidad 'Productos'
//Extiende JpaRepository para aprovechar sus métodos CRUD estándar
@Repository
public interface ProductoRepository extends JpaRepository<Productos, Long>{

}