package com.example.Tienda.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Tienda.entities.ErrorMessage;
import com.example.Tienda.entities.Productos;
import com.example.Tienda.exceptions.ValidationException;
import com.example.Tienda.services.ProductoServiceImpl;

@RestController  // Controlador REST para gestionar los productos
@RequestMapping("/productos/*")
@CrossOrigin(value = "http://localhost:4200") // Permite solicitudes CORS desde el frontend en Angular (localhost:4200)
public class ProductosController {
	
	// Servicio para manejar la lógica de negocio de los productos
	@Autowired
	private ProductoServiceImpl productoServiceImpl;
	
	// Endpoint para obtener todos los productos
	@GetMapping
	public ResponseEntity<List<Productos>> getAll() {
		return ResponseEntity.ok(productoServiceImpl.getAll());
	}
	
	// Endpoint para obtener un producto por su ID
	@GetMapping("{id}")
	public ResponseEntity<Productos> getById(@PathVariable Long id){
		Optional<Productos> optionalProducto = productoServiceImpl.getById(id);
		if(optionalProducto.isPresent()) {
			return ResponseEntity.ok(optionalProducto.orElseThrow());
		}
		return ResponseEntity.notFound().build();
	}
	
	// Endpoint para crear un nuevo producto
	@PostMapping
	public ResponseEntity<Productos> create(@RequestBody Productos producto){
		return ResponseEntity.status(HttpStatus.CREATED).body(productoServiceImpl.save(producto));
	}
	
	// Endpoint para actualizar un producto existente por su ID
	@PutMapping("{id}")
	public ResponseEntity<Productos> update(@RequestBody Productos producto, @PathVariable Long id){
		Optional<Productos> opcionalProducto = productoServiceImpl.getById(id);
		if(opcionalProducto.isPresent()) {
			Productos productoDb = opcionalProducto.orElseThrow();
			productoDb.setNombre(producto.getNombre());
			productoDb.setPrecio(producto.getPrecio());
			productoDb.setDescripcion(producto.getDescripcion());
			productoDb.setStock(producto.getStock());
			return ResponseEntity.status(HttpStatus.CREATED).body(productoServiceImpl.save(productoDb));
		}
		return ResponseEntity.notFound().build();
	}
	
	// Endpoint para eliminar un producto por su ID
	@DeleteMapping("{id}")
	public ResponseEntity<Productos> delete(@PathVariable Long id){
		Optional<Productos> optionalProducto= productoServiceImpl.getById(id);
		if(optionalProducto.isPresent()) {
			Productos productoDeleted = productoServiceImpl.deleteById(id).orElseThrow();
			return ResponseEntity.status(HttpStatus.OK).body(productoDeleted);
		}
		return ResponseEntity.notFound().build();
	}
	
	// Manejo de excepciones de validación
	@ExceptionHandler(ValidationException.class)
	// En caso de que se lance una excepción de validación, devuelve un error con mensaje
	public ResponseEntity<ErrorMessage> handleValidationException(ValidationException ex) {
	    return ResponseEntity.status(HttpStatus.BAD_REQUEST)
	                         .body(new ErrorMessage("Validación fallida", ex.getMessage()));
	}

}