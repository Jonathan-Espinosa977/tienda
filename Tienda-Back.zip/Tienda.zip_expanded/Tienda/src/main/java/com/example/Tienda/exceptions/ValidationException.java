package com.example.Tienda.exceptions;

//Excepción personalizada para manejar errores de validación
//Extiende de RuntimeException, lo que la convierte en una excepción no verificada
public class ValidationException extends RuntimeException{
	
	// Constructor que recibe un mensaje de error para proporcionar detalles sobre la excepción
	public ValidationException(String message) {
		super(message);
	}
}