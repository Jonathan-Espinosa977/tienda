package com.example.Tienda.repositories;

import java.util.List;
import java.util.Optional;

public interface IService<T> {
	
	List<T> getAll();  // Método para obtener todos los elementos

    Optional<T> getById(Long id);  // Método para obtener un elemento por su ID

    T save(T item);  // Método para guardar un nuevo elemento

    Optional<T> deleteById(Long id);  // Método para eliminar un elemento por su ID
}
