package com.example.Tienda.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Tienda.entities.Productos;
import com.example.Tienda.exceptions.ValidationException;
import com.example.Tienda.repositories.IService;
import com.example.Tienda.repositories.ProductoRepository;

@Service // Implementación del servicio para manejar la lógica de negocio de los productos
public class ProductoServiceImpl implements IService<Productos>{
	
	@Autowired
	private ProductoRepository productoRepository; // Repositorio que maneja las operaciones con la base de datos
	
	// Método para obtener todos los productos de la base de datos
	@Transactional(readOnly = true)
	@Override
	public List<Productos> getAll() {
		return productoRepository.findAll();
	}

	// Método para obtener un producto por su ID
	@Transactional(readOnly = true)
	@Override
	public Optional<Productos> getById(Long id) {
		return productoRepository.findById(id);
	}

	// Método para guardar un nuevo producto o actualizar uno existente
	@Transactional
	@Override
	public Productos save(Productos item) {
		// Validaciones para asegurar que los datos del producto sean correctos
		if (item.getNombre() == null || item.getNombre().isEmpty()) {
	        throw new ValidationException("El nombre del producto no puede estar vacío.");
	    }
	    if (item.getPrecio() < 0) {
	        throw new ValidationException("El precio no puede ser negativo.");
	    }
	    if (item.getDescripcion() == null || item.getDescripcion().isEmpty()) {
	        throw new ValidationException("La descripción del producto es obligatoria.");
	    }
	    if (item.getStock() < 0) {
	        throw new ValidationException("El stock no puede ser negativo.");
	    }
		return productoRepository.save(item);
	}

	// Método para eliminar un producto por su ID
	@Transactional
	@Override
	public Optional<Productos> deleteById(Long id) {
	    Optional<Productos> productoOptional = productoRepository.findById(id);
	    if (productoOptional.isPresent()) {
	        productoRepository.deleteById(id);
	        return productoOptional;
	    }
	    return null;
	}
}